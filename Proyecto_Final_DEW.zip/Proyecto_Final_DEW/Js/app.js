let products = [
    { id: 1, name: "Producto 1", precioOriginal: 100, precioActual: 100 },
    { id: 2, name: "Producto 2", precioOriginal: 150, precioActual: 150 },
    { id: 3, name: "Producto 3", precioOriginal: 200, precioActual: 200 },
    { id: 4, name: "Producto 4", precioOriginal: 120, precioActual: 120 },
    { id: 5, name: "Producto 5", precioOriginal: 80, precioActual: 80 },
];

// Cargar productos desde localStorage si existen
function loadProducts() {
    const storedProducts = localStorage.getItem("products"); // Obtiene los productos del localStorage
    if (storedProducts) {
        products = JSON.parse(storedProducts); // Si existen, se parsea y se asigna a la variable "products"
    }
}

// Guardar productos en localStorage
function saveProducts() {
    localStorage.setItem("products", JSON.stringify(products)); // Guarda la lista de productos en el localStorage
}

// Actualizar el precio de un producto en el Panel de Admin
function updateProductPrice(productId, newPrice) {
    const product = products.find(p => p.id === productId); // Busca el producto con el id proporcionado
    if (product) {
        product.precioActual = newPrice; // Si se encuentra el producto, actualiza su precio
        saveProducts(); // Guarda los cambios en localStorage
    }
}

let currentRotation = 0;

// Función para rotar el slider (para mostrar diferentes productos en una vista en 3D)
function rotateSlider(degrees) {
    currentRotation += degrees; // Incrementa la rotación actual del slider
    document.getElementById("slider").style.transform = `rotateY(${currentRotation}deg)`; // Aplica la rotación al contenedor del slider
}

// Inicializar productos para la Vista de Usuario
function initializeUserView() {
    const slider = document.getElementById("slider"); // Obtiene el contenedor del slider
    if (slider) {
        slider.innerHTML = ""; // Limpiar el contenido previo del slider

        products.forEach(product => {
            const slide = document.createElement("div"); // Crea un div para cada producto en el slider
            slide.className = "slide"; // Le asigna la clase "slide"
            slide.id = `slide${product.id}`; // Le asigna un ID único con el ID del producto

            // Ruta dinámica para la imagen del producto (suponiendo que las imágenes están en la carpeta ../img/)
            const imagePath = `../img/producto${product.id}.jpg`; // Ruta de la imagen, asumiendo un patrón de nombres

            // Inserta el HTML dentro del contenedor de la diapositiva
            slide.innerHTML = `
                <div class="frontside">
                    <p id="product${product.id}-name">${product.name}</p>
                    <!-- Imagen del producto con ruta dinámica -->
                    <img src="../img/producto${product.id}.jpg" alt="${product.name}" style="width: 150px; height: 150px; object-fit: cover; border-radius: 8px;">
                    <p id="product${product.id}-price">Precio Actual: $${product.precioActual.toFixed(2)}</p>
                    <p id="product${product.id}-original">Precio Original: $${product.precioOriginal.toFixed(2)}</p>
                    <button onclick="addToCart(${product.id})">Agregar al Carrito</button>
                </div>
            `;
            slider.appendChild(slide); // Añade la diapositiva al contenedor del slider
        });
    }
}

// Agregar al carrito (código existente reutilizado)
function addToCart(productId) {
    const product = products.find(p => p.id === productId); // Busca el producto con el ID proporcionado
    const cartItems = document.getElementById("cart-items"); // Obtiene el contenedor de los elementos del carrito

    const existingRow = document.querySelector(`#cart-items tr[data-id='${productId}']`); // Verifica si el producto ya está en el carrito
    if (existingRow) {
        const quantityCell = existingRow.querySelector(".quantity"); // Si existe, se busca la celda de cantidad
        quantityCell.textContent = parseInt(quantityCell.textContent) + 1; // Se incrementa la cantidad
    } else {
        const row = document.createElement("tr"); // Si no existe, crea una nueva fila en el carrito
        row.setAttribute("data-id", productId); // Establece el ID del producto como un atributo de datos

        // Inserta el contenido HTML de la fila con el nombre del producto, precio y cantidad
        row.innerHTML = `
            <td>${product.name}</td>
            <td>$${product.precioActual.toFixed(2)}</td>
            <td class="quantity">1</td>
            <td><button onclick="removeFromCart(${productId})">❌</button></td>
        `;
        cartItems.appendChild(row); // Añade la fila al carrito
    }

    updateTotal(); // Actualiza el total del carrito
}

// Remover del carrito
function removeFromCart(productId) {
    const row = document.querySelector(`#cart-items tr[data-id='${productId}']`); // Busca la fila del producto en el carrito
    if (row) {
        const quantityCell = row.querySelector(".quantity"); // Busca la celda de cantidad
        const newQuantity = parseInt(quantityCell.textContent) - 1; // Disminuye la cantidad

        if (newQuantity > 0) {
            quantityCell.textContent = newQuantity; // Si la cantidad es mayor que 0, se actualiza
        } else {
            row.remove(); // Si la cantidad es 0, se elimina la fila del carrito
        }
    }

    updateTotal(); // Actualiza el total del carrito
}

// Actualizar el total del carrito
function updateTotal() {
    const rows = document.querySelectorAll("#cart-items tr"); // Obtiene todas las filas del carrito
    let total = 0; // Inicializa la variable total

    rows.forEach(row => {
        const price = parseFloat(row.children[1].textContent.replace("$", "")); // Obtiene el precio de cada producto
        const quantity = parseInt(row.querySelector(".quantity").textContent); // Obtiene la cantidad del producto
        total += price * quantity; // Suma el total
    });

    const totalElement = document.getElementById("total"); // Obtiene el elemento del total
    if (totalElement) {
        totalElement.textContent = `Total: $${total.toFixed(2)}`; // Muestra el total con formato
    }
}

// Inicializar para cada vista
window.onload = function () {
    loadProducts(); // Carga los productos al iniciar la página
    if (document.title.includes("Panel de Administrador")) {
        // La inicialización del admin se maneja en admin.html
    } else {
        initializeUserView(); // Si no está en el panel de admin, inicializa la vista de usuario
    }
};

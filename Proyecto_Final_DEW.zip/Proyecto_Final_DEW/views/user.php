<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras - Usuario</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
 

    <div class="slider-container">
        <div class="slider" id="slider">
            <!-- Los productos se generarán dinámicamente aquí -->
        </div>
    </div>

    <div class="nav-buttons">
        <script src="../Js/app.js">  </script>
        <button class="nav-button" onclick="rotateSlider(72)">⬅️ Anterior</button>
        <button class="nav-button" onclick="rotateSlider(-72)">Siguiente ➡️</button>
    </div>

    <div id="carrito">
        <h2>Tu Carrito</h2>
        <table>
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Eliminar</th>
                </tr>
            </thead>
            <tbody id="cart-items">
                <!-- Los productos del carrito se agregarán aquí -->
            </tbody>
        </table>
        <p class="total" id="total">Total: $0.00</p>
    </div>

    <script src="../Js/app.js"></script>
      <!-- Botón para volver al menú -->
      <form method="POST" action="../index.php">
            <button name="volverIndice"><?php echo   'Volver a Menú'  ?></button>
        </form>
        <!-- Formulario de cierre de sesión -->
        <form method="POST" action="logout.php">
            <button type="submit" name="limpiar"><?php echo   'Cerrar Sesión'   ?></button>
        </form>
</body>
</html>
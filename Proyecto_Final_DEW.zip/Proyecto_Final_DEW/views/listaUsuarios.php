<?php
session_start();

// Cargar preferencias de idioma y estilo desde las cookies
$language = isset($_COOKIE['language']) ? $_COOKIE['language'] : 'es'; // Valor predeterminado: español
$style = isset($_COOKIE['style']) ? $_COOKIE['style'] : 'light'; // Valor predeterminado: estilo claro (light)

// Función para cargar los usuarios desde el archivo
function cargarUsuarios($archivo) {
    $usuarios = [];
    if (file_exists($archivo)) {
        $lineas = file($archivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lineas as $linea) {
            $partes = explode('|', $linea); // Separar los valores por el delimitador '|'
            if (count($partes) === 3 && trim($partes[2]) === 'user') { // Verificar que sea un usuario con rol "user"
                $usuarios[] = trim($partes[0]); // Guardar solo el nombre de usuario
            }
        }
    }
    return $usuarios;
}

// Función para eliminar usuarios seleccionados
function eliminarUsuarios($archivo, $usuariosSeleccionados) {
    if (file_exists($archivo)) {
        $lineas = file($archivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $nuevasLineas = [];
        foreach ($lineas as $linea) {
            $partes = explode('|', $linea);
            if (count($partes) === 3 && !in_array(trim($partes[0]), $usuariosSeleccionados)) {
                $nuevasLineas[] = $linea; // Conservar las líneas no seleccionadas
            }
        }
        file_put_contents($archivo, implode(PHP_EOL, $nuevasLineas)); // Guardar cambios en el archivo
    }
}

$archivoUsuarios = 'users.txt'; // Ruta al archivo de usuarios

// Manejar la eliminación de usuarios seleccionados
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['usuarios'])) {
    eliminarUsuarios($archivoUsuarios, $_POST['usuarios']);
}

// Cargar la lista de usuarios desde el archivo
$usuarios = cargarUsuarios($archivoUsuarios);
?>

<!DOCTYPE html>
<html lang="<?php echo $language; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $language === 'es' ? 'Eliminar Usuarios' : 'Delete Users'; ?></title>
    <!-- Carga dinámica del estilo según las preferencias guardadas en las cookies -->
    <link rel="stylesheet" href="../css/style-<?php echo $style; ?>.css">
</head>
<body>
<header>
    <div class="header-links">
        <!-- Botón Ajustes -->
        <form method="POST" action="preferencias.php">
            <input type="hidden" name="source" value="listUser"> <!-- Campo oculto con el origen -->
            <button type="submit" class="btn-link">
                <img src="../img/settings-icon-<?php echo $style === 'dark' ? 'oscuro' : 'claro'; ?>.png" alt="<?php echo $language === 'en' ? 'Settings' : 'Ajustes'; ?>" class="icono">
                <?php echo $language === 'en' ? 'Settings' : 'Ajustes'; ?>
            </button>
        </form>
        <!-- Botón para volver al menú -->
        <form method="POST" action="../index.php">
            <button name="volverIndice"><?php echo $language === 'es' ? 'Volver a Menú' : 'Back to Menu'; ?></button>
        </form>
        <!-- Formulario de cierre de sesión -->
        <form method="POST" action="logout.php">
            <button type="submit" name="limpiar"><?php echo $language === 'es' ? 'Cerrar Sesión' : 'Logout'; ?></button>
        </form>
    </div>
</header>

<div class="panel">
    <h1><?php echo $language === 'es' ? 'Eliminar Usuarios' : 'Delete Users'; ?></h1>
    <?php if (!empty($usuarios)): ?>
        <form method="POST">
            <table>
                <thead>
                    <tr>
                        <th><?php echo $language === 'es' ? 'Usuario' : 'User'; ?></th>
                        <th><?php echo $language === 'es' ? 'Seleccionar' : 'Select'; ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usuarios as $usuario): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($usuario); ?></td>
                            <td>
                                <input type="checkbox" name="usuarios[]" value="<?php echo htmlspecialchars($usuario); ?>">
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <button type="submit"><?php echo $language === 'es' ? 'Eliminar Usuarios Seleccionados' : 'Delete Selected Users'; ?></button>
        </form>
    <?php else: ?>
        <p><?php echo $language === 'es' ? 'No hay usuarios disponibles para eliminar.' : 'No users available to delete.'; ?></p>
    <?php endif; ?>
</div>
</body>
</html>

<?php
session_start(); // Inicia o reanuda una sesión de usuario para manejar el inicio de sesión y la persistencia de datos.
?>
<!DOCTYPE html>
<html lang="es"> <!-- Define que el idioma del contenido es español -->
<head>
    <meta charset="UTF-8"> <!-- Establece la codificación de caracteres a UTF-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Hace que la página sea responsiva, adaptándose a dispositivos móviles -->
    <title>Panel de Administrador - Carrito de Compras</title> <!-- Título que aparece en la pestaña del navegador -->
    <link rel="stylesheet" href="../css/styles.css"> <!-- Vincula el archivo CSS para los estilos de la página -->
</head>
<body>
  
    <div class="slider-container"> <!-- Contenedor para el slider que muestra los productos -->
        <div class="slider" id="slider"> <!-- Contenedor donde se agregarán los productos dinámicamente -->
            <!-- Los productos se generarán aquí dinámicamente con JavaScript -->
        </div>
    </div>

    <div class="nav-buttons"> <!-- Botones de navegación para controlar el slider -->
        <button class="nav-button" onclick="rotateSlider(72)">⬅️ Anterior</button> <!-- Botón para rotar el slider hacia la izquierda -->
        <button class="nav-button" onclick="rotateSlider(-72)">Siguiente ➡️</button> <!-- Botón para rotar el slider hacia la derecha -->
    </div>

<script>
let currentRotation = 0; // Variable que guarda el valor de la rotación actual del slider
let products = [ // Array con los productos iniciales que se mostrarán
    { id: 1, name: "Producto 1", precioOriginal: 100, precioActual: 100 },
    { id: 2, name: "Producto 2", precioOriginal: 150, precioActual: 150 },
    { id: 3, name: "Producto 3", precioOriginal: 200, precioActual: 200 },
    { id: 4, name: "Producto 4", precioOriginal: 120, precioActual: 120 },
    { id: 5, name: "Producto 5", precioOriginal: 80, precioActual: 80 }
];

// Función que carga los productos desde el localStorage, si están almacenados
function loadProducts() {
    const storedProducts = localStorage.getItem("products"); // Intenta obtener los productos guardados en localStorage
    if (storedProducts) {
        products = JSON.parse(storedProducts); // Si existen, los convierte de JSON a objetos de JavaScript
    }
}

// Función que guarda los productos actuales en el localStorage
function saveProducts() {
    localStorage.setItem("products", JSON.stringify(products)); // Guarda los productos como una cadena JSON en localStorage
}

// Función que inicializa el slider generando dinámicamente las diapositivas para cada producto
function initializeSlider() {
    const slider = document.getElementById("slider"); // Obtiene el contenedor del slider
    slider.innerHTML = ""; // Limpia el contenido previo de diapositivas

    // Recorre el array de productos y crea una diapositiva para cada uno
    products.forEach(product => {
        const slide = document.createElement("div"); // Crea un contenedor para cada diapositiva
        slide.className = "slide"; // Asigna la clase "slide" al contenedor
        slide.id = `slide${product.id}`; // Asigna un ID único a cada diapositiva basado en el ID del producto

        // Se genera dinámicamente la ruta de la imagen del producto
        const imagePath = `../img/producto${product.id}.jpg`;

        slide.innerHTML = ` <!-- HTML para cada diapositiva -->
            <div class="frontside">
                <p id="product${product.id}-name">${product.name}</p> <!-- Muestra el nombre del producto -->
                <img src="../img//producto${product.id}.jpg" alt="${product.name}" style="width: 120px; height: 120px; object-fit: cover; border-radius: 8px;"> <!-- Muestra la imagen del producto -->
                <p id="product${product.id}-price">Precio Actual: $${product.precioActual.toFixed(2)}</p> <!-- Muestra el precio actual del producto -->
                <p id="product${product.id}-original">Precio Original: $${product.precioOriginal.toFixed(2)}</p> <!-- Muestra el precio original del producto -->
                <label for="discount${product.id}">Descuento: 
                    <span id="discount${product.id}-value">0%</span>
                    <!-- Control deslizante para aplicar un descuento -->
                    <input type="range" id="discount${product.id}" class="discount-slider" value="0" max="100" onchange="applyDiscount(${product.id})"> 
                    <button onclick="updatePrice(${product.id})">Actualizar Precio</button> <!-- Botón para actualizar el precio con el descuento -->
                </label>
            </div>
        `;
        slider.appendChild(slide); // Añade la diapositiva al slider
    });
}

// Función para rotar el slider en la dirección indicada
function rotateSlider(degrees) {
    currentRotation += degrees; // Actualiza el valor de la rotación
    document.getElementById("slider").style.transform = `rotateY(${currentRotation}deg)`; // Aplica la rotación al slider
}

// Función para aplicar un descuento al producto seleccionado
function applyDiscount(productId) {
    const product = products.find(p => p.id === productId); // Encuentra el producto con el ID proporcionado
    const discountValue = document.getElementById(`discount${productId}`).value; // Obtiene el valor del descuento (0-100)
    const discountedPrice = product.precioOriginal * (1 - discountValue / 100); // Calcula el nuevo precio con el descuento aplicado

    product.precioActual = discountedPrice; // Actualiza el precio actual del producto
    document.getElementById(`product${productId}-price`).textContent = `Precio Actual: $${discountedPrice.toFixed(2)}`; // Muestra el precio actualizado
    document.getElementById(`discount${productId}-value`).textContent = `${discountValue}%`; // Muestra el porcentaje de descuento aplicado
}

// Función para actualizar el precio de un producto tras aplicar el descuento
function updatePrice(productId) {
    const product = products.find(p => p.id === productId); // Encuentra el producto con el ID proporcionado
    product.precioActual = parseFloat(document.getElementById(`product${productId}-price`).textContent.replace('Precio Actual: $', '')); // Obtiene el nuevo precio
    saveProducts(); // Guarda los productos con el precio actualizado en el localStorage
    alert(`Precio actualizado para ${product.name}: $${product.precioActual.toFixed(2)}`); // Muestra una alerta confirmando que el precio se actualizó
}

// Función que se ejecuta cuando la página se carga
window.onload = function() {
    loadProducts(); // Carga los productos almacenados
    initializeSlider(); // Inicializa el slider generando las diapositivas de los productos
};
</script>

    <script src="../Js/app.js"></script> <!-- Vincula el archivo JavaScript adicional si es necesario -->
  
    <!-- Formulario para volver al menú principal -->
    <form method="POST" action="../index.php">
        <button name="volverIndice"><?php echo 'Volver a Menú'; ?></button> <!-- Botón para regresar al menú principal -->
    </form>
    
    <!-- Formulario para cerrar sesión -->
    <form method="POST" action="logout.php">
        <button type="submit" name="limpiar"><?php echo 'Cerrar Sesión'; ?></button> <!-- Botón para cerrar sesión -->
    </form>
</body>
</html>
